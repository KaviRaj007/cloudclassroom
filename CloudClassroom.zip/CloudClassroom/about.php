        <?php include('allhead.php'); ?>
        <!-- Page Content -->
        <div class="container" style="max-width: 1200px;">

        <!-- Page Heading/Breadcrumbs -->
        <div class="row">
        <div class="col-lg-12">
        <h1 class="page-header">About
        <small>Cloud Classroom</small>
        </h1>
        <ol class="breadcrumb">
        <li><a href=" index">Home</a>
        </li>
        <li class="active">About</li>
     </ol>
        </div>
        </div>
        <!-- /.row -->

        <!-- Intro Content -->
        <div class="row">
        <div class="col-md-6 image-center">
        <img class="img-responsive" src="images/pic3.jpg" alt="">
        </div>
        <div class="col-md-6">
        <h2>ABOUT PEC</h2>
        <p>The <strong>“Pondicherry Engineering College"</strong>is an Institution
         promoted and fully funded by the Government of Puducherry. The College was started in 1984 
         under the VII Five Year Plan. It is an autonomous Institution for the purposes of administration,
         staff recruitment and College development and is managed by a Board of Governors. The College
         is affiliated to Pondicherry University, Pondicherry, for the academic purposes. The College
         has been growing from strength to strength since its inception. PEC is ranked 122 in Engineering 
         Category by NIRF India Rankings 2020.</p><br>
<p>
In this website, student can attend his\her assessments and video classes from e-learn.</p>
        </div>
        </div>
        <!-- /.row -->

        <!-- Team Members -->
        <div class="row">
        <div class="col-lg-12">
        <h2 class="page-header">FACULTY MEMBERS</h2>
        </div>
        <div class="col-md-4 text-center">
        <div class="thumbnail">
        <img class="img-responsive" src="images/new/44.jpg" alt="">
        <div class="caption">
        <h3>DR.R.MANOGARAN<br>
            <small>HEAD OF THE DEPARTMENT</small>
        </h3>
        </div>
        </div>
        </div>
        <div class="col-md-4 text-center">
        <div class="thumbnail">
        <img class="img-responsive" src="images/new/33.jpg" alt="">
        <div class="caption">
        <h3>DR.D.LOGANATHAN<br>
            <small>PROFESSOR</small>
        </h3>
        </div>
        </div>
        </div>
        <div class="col-md-4 text-center">
        <div class="thumbnail">
        <img class="img-responsive" src="images/new/11.jpg" alt="">
        <div class="caption">
        <h3>DR.G.ZAYARAZ<br>
            <small>PROFESSOR</small>
        </h3>
        </div>
        </div>
        </div>
        <div class="col-md-4 text-center">
        <div class="thumbnail">
        <img class="img-responsive" src="images/new/77.jpg" alt="">
        <div class="caption">
        <h3>DR.E.KARUNAKARAN<br>
            <small>ASSOCIATE PROFESSOR</small>
        </h3>
        </div>
        </div>
        </div>
        <div class="col-md-4 text-center">
        <div class="thumbnail">
        <img class="img-responsive" src="images/new/66.jpg" alt="">
        <div class="caption">
        <h3>DR.M.THENMOZHI<br>
            <small>ASSISTANT PROFESSOR</small>
        </h3>
        </div>
        </div>
        </div>
        <div class="col-md-4 text-center">
        <div class="thumbnail">
        <img class="img-responsive" src="images/new/22.jpg" alt="">
        <div class="caption">
        <h3>DR.R.KAVITHA KUMAR<br>
            <small>PROGRAMMER</small>
        </h3>
        </div>
        </div>
        </div>
        </div>
        <!-- /.row -->

        <!-- Our Customers -->
        <div class="row">
        <div class="col-lg-12">
            <h2 class="page-header">Our Student's</h2>
        </div>
        <div class="col-md-2 col-sm-4 col-xs-6">
        <img class="img-responsive customer-img" src="images/welcome46.jpg" alt="">
        </div>
        <div class="col-md-2 col-sm-4 col-xs-6">
        <img class="img-responsive customer-img" src="images/smilingFemaleStudent.jpg" alt="">
        </div>
        <div class="col-md-2 col-sm-4 col-xs-6">
        <img class="img-responsive customer-img" src="images/Returning-Student.jpg" alt="">
        </div>
        <div class="col-md-2 col-sm-4 col-xs-6">
        <img class="img-responsive customer-img" src="images/Hopeful_student_1.jpg" alt="">
        </div>
        <div class="col-md-2 col-sm-4 col-xs-6">
        <img class="img-responsive customer-img" src="images/happy_student4.jpg" alt="">
        </div>
        <div class="col-md-2 col-sm-4 col-xs-6">
        <img class="img-responsive customer-img" src="images/library_guy_900x400.jpg" alt="">
        </div>
        </div>
        <!-- /.row -->

        <hr>
        <!-- Footer -->
        <footer>

       

        </footer>

        </div>
        <!-- /.container -->
        <style>

        .footer{background: #000; padding: 10px 0px; color: #fff;position: fixed;left: 0; right: 0;bottom: -10px;}

        </style>
        <!-- jQuery -->
        <script src="js/jquery.js"></script>

        <!-- Bootstrap Core JavaScript -->
        <script src="js/bootstrap.min.js"></script>

        <!-- Script to Activate the Carousel -->
        <script>
        $('.carousel').carousel({
        interval: 5000 //changes the speed
        })
        </script>

        </body>
        </html>
